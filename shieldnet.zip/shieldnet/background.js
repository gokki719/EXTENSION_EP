// ============================================================
//  ShieldNet — background.js (Service Worker)
//  Motor principal: analiza URLs, dominios y coordina módulos
// ============================================================

importScripts('domainScorer.js');

// ── Listas negras offline (dominios conocidos de phishing) ──
const BLACKLIST = new Set([
  "secure-login-banorte.xyz", "bancomer-seguro.net", "paypal-verify.tk",
  "amazon-soporte.ml", "apple-id-locked.cf", "netflix-actualizar.ga",
  "microsoft-support-alert.com", "google-security-check.tk",
  "sat-devolucion.xyz", "imss-tramites-online.ml", "bbva-seguridad.cf",
  "hsbc-verificacion.tk", "santander-alerta.ga", "banamex-secure.ml"
]);

// ── Dominios legítimos conocidos (para detectar typosquatting) ──
const LEGIT_DOMAINS = [
  "banorte.com", "bancomer.com", "bbva.mx", "hsbc.com.mx",
  "santander.com.mx", "banamex.com", "paypal.com", "amazon.com.mx",
  "apple.com", "microsoft.com", "google.com", "netflix.com",
  "sat.gob.mx", "imss.gob.mx", "facebook.com", "instagram.com"
];

// ── Estado global en memoria ──
let stats = { blocked: 0, suspicious: 0, safe: 0, adsBlocked: 0 };
let siteCache = new Map(); // cache de resultados por dominio

// ============================================================
//  LISTENER: cada vez que se navega a una URL
// ============================================================
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return; // solo frame principal
  
  const url = details.url;
  if (!url.startsWith('http')) return; // ignorar chrome://, etc.

  try {
    const result = await analyzeDomain(url);
    
    // Guardar en cache y storage
    siteCache.set(extractDomain(url), result);
    await chrome.storage.local.set({ 
      lastResult: result,
      stats: stats 
    });

    // Notificar al content script
    chrome.tabs.sendMessage(details.tabId, {
      type: 'DOMAIN_RESULT',
      result: result
    }).catch(() => {}); // ignorar si el tab no tiene content script listo

    // Mostrar alerta si es peligroso
    if (result.risk === 'DANGER') {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: '🚨 ShieldNet — Sitio Peligroso',
        message: `El dominio "${result.domain}" fue detectado como peligroso. Se recomienda salir.`,
        priority: 2
      });
      stats.blocked++;
    } else if (result.risk === 'WARNING') {
      stats.suspicious++;
    } else {
      stats.safe++;
    }

    await chrome.storage.local.set({ stats });

  } catch (err) {
    console.error('[ShieldNet] Error analizando dominio:', err);
  }
});

// ============================================================
//  FUNCIÓN PRINCIPAL: analizar un dominio completo
// ============================================================
async function analyzeDomain(url) {
  const domain = extractDomain(url);
  const isHTTPS = url.startsWith('https://');

  // Verificar cache primero
  if (siteCache.has(domain)) {
    return siteCache.get(domain);
  }

  const checks = {
    isHTTPS,
    inBlacklist: BLACKLIST.has(domain),
    isTyposquatting: detectTyposquatting(domain),
    domainAge: await checkDomainAge(domain),
    safeBrowsing: await checkGoogleSafeBrowsing(url),
    hasSuspiciousKeywords: hasSuspiciousKeywords(domain)
  };

  const score = calculateScore(checks);
  const risk = score >= 70 ? 'SAFE' : score >= 40 ? 'WARNING' : 'DANGER';

  return {
    domain,
    url,
    score,
    risk,
    checks,
    timestamp: Date.now()
  };
}

// ============================================================
//  DETECTOR DE TYPOSQUATTING
//  Detecta si el dominio imita a uno legítimo (ej: "paypa1.com")
// ============================================================
function detectTyposquatting(domain) {
  const domainBase = domain.replace(/^www\./, '').split('.')[0].toLowerCase();
  
  for (const legit of LEGIT_DOMAINS) {
    const legitBase = legit.split('.')[0].toLowerCase();
    
    // Distancia de Levenshtein
    const dist = levenshtein(domainBase, legitBase);
    
    // Si es MUY similar pero no idéntico → sospechoso
    if (dist > 0 && dist <= 2 && domainBase !== legitBase) {
      return { detected: true, imitates: legit, distance: dist };
    }

    // Detectar sustituciones comunes: l→1, o→0, rn→m
    const normalized = domainBase
      .replace(/1/g, 'l').replace(/0/g, 'o')
      .replace(/rn/g, 'm').replace(/vv/g, 'w');
    if (normalized === legitBase && domainBase !== legitBase) {
      return { detected: true, imitates: legit, method: 'char_substitution' };
    }
  }

  return { detected: false };
}

// Algoritmo de Levenshtein (distancia de edición)
function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) =>
    Array.from({ length: b.length + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = a[i-1] === b[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
    }
  }
  return dp[a.length][b.length];
}

// ============================================================
//  KEYWORDS SOSPECHOSAS en el dominio
// ============================================================
function hasSuspiciousKeywords(domain) {
  const suspicious = [
    'secure', 'login', 'verify', 'account', 'update', 'confirm',
    'banking', 'soporte', 'seguro', 'verificar', 'actualizar',
    'premio', 'ganaste', 'urgente', 'alerta', 'suspended', 'locked',
    'recovery', 'restore', 'support', 'helpdesk', 'free', 'gratis'
  ];
  const lower = domain.toLowerCase();
  const found = suspicious.filter(k => lower.includes(k));
  return { detected: found.length > 0, keywords: found };
}

// ============================================================
//  GOOGLE SAFE BROWSING API
//  (Necesitan poner su API key de Google Cloud Console — gratis)
// ============================================================
async function checkGoogleSafeBrowsing(url) {
  const API_KEY = 'TU_API_KEY_AQUI'; // ← Cambiar por su key real
  
  // Si no tienen API key configurada, skip
  if (API_KEY === 'TU_API_KEY_AQUI') {
    return { checked: false, safe: true };
  }

  try {
    const response = await fetch(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client: { clientId: 'shieldnet', clientVersion: '1.0.0' },
          threatInfo: {
            threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE'],
            platformTypes: ['ANY_PLATFORM'],
            threatEntryTypes: ['URL'],
            threatEntries: [{ url }]
          }
        })
      }
    );
    const data = await response.json();
    return { 
      checked: true, 
      safe: !data.matches || data.matches.length === 0,
      threats: data.matches || []
    };
  } catch {
    return { checked: false, safe: true };
  }
}

// ============================================================
//  EDAD DEL DOMINIO via API pública
// ============================================================
async function checkDomainAge(domain) {
  try {
    // Usar whoisxmlapi.com (tienen plan gratuito)
    const response = await fetch(
      `https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=TU_WHOIS_API_KEY&domainName=${domain}&outputFormat=JSON`
    );
    const data = await response.json();
    const createdDate = data?.WhoisRecord?.createdDate;
    
    if (createdDate) {
      const created = new Date(createdDate);
      const ageDays = Math.floor((Date.now() - created.getTime()) / 86400000);
      return { 
        known: true, 
        ageDays,
        ageCategory: ageDays < 30 ? 'NEW' : ageDays < 365 ? 'RECENT' : 'OLD'
      };
    }
  } catch {}
  
  return { known: false, ageDays: null, ageCategory: 'UNKNOWN' };
}

// ============================================================
//  CALCULAR SCORE FINAL (0-100)
// ============================================================
function calculateScore(checks) {
  let score = 100;

  if (!checks.isHTTPS)                     score -= 35; // HTTP sin cifrado = muy malo
  if (checks.inBlacklist)                  score -= 50; // En lista negra = peligro
  if (checks.isTyposquatting.detected)     score -= 40; // Imitando otro dominio
  if (!checks.safeBrowsing.safe)           score -= 40; // Google lo marcó
  if (checks.hasSuspiciousKeywords.detected) score -= 15; // Palabras sospechosas

  // Penalizar dominios nuevos
  if (checks.domainAge.ageCategory === 'NEW')    score -= 20;
  if (checks.domainAge.ageCategory === 'RECENT') score -= 10;

  return Math.max(0, Math.min(100, score));
}

// ============================================================
//  UTILIDADES
// ============================================================
function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

// ── Mensajes desde popup ──
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_CURRENT_RESULT') {
    chrome.storage.local.get(['lastResult', 'stats'], (data) => {
      sendResponse(data);
    });
    return true; // async
  }
  
  if (msg.type === 'ANALYZE_URL') {
    analyzeDomain(msg.url).then(sendResponse);
    return true;
  }

  if (msg.type === 'GET_STATS') {
    chrome.storage.local.get('stats', (data) => {
      sendResponse(data.stats || stats);
    });
    return true;
  }
});
